# Object-Detection-and-distance-
We created a project that is able to detect distance of a object using a video feed or cam feed.
